﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            textBox2.Text = " ";
            label2.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {

            double resultado=0;
            
            bool valida1 = false, valida2 = false;

            

            Numero a = new Numero(this.textBox1.Text);
            Numero b = new Numero(this.textBox2.Text);

            //this.label2.Text = Calculadora.operacion(a, b, comboBox1.Text);

            // Validacion
            /*while (valida1 == false) {
                valida1 = int.TryParse(textBox1.Text, out a);    
            }

            while (valida2 == false) {
                valida2 = int.TryParse(textBox2.Text, out b);
            }

            if (comboBox1.Text == "/" && b == 0)
            {
                MessageBox.Show(error);
            }
            else {
            // Operacion
                operador = comboBox1.Text;
                resultado = Calculadora.operacion(a, b, operador);
                label2.Text = resultado.ToString();
            }
            */

            //resultado = Calculadora.operacion(a.getNumero, b.getNumero, comboBox1.Text);
        }
    }
}
