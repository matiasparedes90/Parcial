﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP01
{
    class Numero
    {

        double numero;

        public Numero() {
            this.numero = 0;
        }

        public Numero(double num)
        {
            this.numero = num;
        }

        public Numero(string num)
        {
            bool validar;
            int valor = 0;
            validar = int.TryParse(num, out valor);

            if (validar == true)
                numero = valor;
            
        }

        public double getNumero()
        {
            return numero;
        }

        private double validarNumero(string num) {
            bool validar;
            double valor;
            validar = double.TryParse(num, out valor);
            if (validar == true)
            {
                return valor;
            }
            else {
                valor = 0;
                return valor;
            }
            
        }
        private void setNumero(string numero) {

            double num;

            num = validarNumero(numero);

            if (num != 0) {
                numero = num.ToString();
            }
        }
    }
}
